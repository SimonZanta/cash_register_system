package com.example.DBConnected.Photos;

import org.springframework.data.repository.CrudRepository;

public interface PhotoRepo extends CrudRepository<Photo,Integer> {
}
