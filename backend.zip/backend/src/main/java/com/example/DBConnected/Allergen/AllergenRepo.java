package com.example.DBConnected.Allergen;

import org.springframework.data.repository.CrudRepository;

public interface AllergenRepo extends CrudRepository<Allergen, Integer> {
}
