package com.example.DBConnected;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//this just starts the app
@SpringBootApplication
public class DBConnectedApplication {

    public static void main(String[] args) {
        SpringApplication.run(DBConnectedApplication.class, args);
    }

}