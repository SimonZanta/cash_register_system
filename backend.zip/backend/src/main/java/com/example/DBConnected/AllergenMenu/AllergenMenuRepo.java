package com.example.DBConnected.AllergenMenu;

import org.springframework.data.repository.CrudRepository;

public interface AllergenMenuRepo extends CrudRepository<AllergenMenu,Integer> {
}
